-- ***************************************************************************
-- Copyright (C) 1991-2002 SQLDev.Net
-- 
-- file:	xpsmtp.sql
-- descr.:	SMTP based SQL Mail
-- author:	Gert E.R. Drapers (GertD@SQLDev.Net)
--
-- @@bof_revsion_marker
-- revision history
-- yyyy/mm/dd  by       description
-- ==========  =======  ==========================================================
-- 2002-08-12  gertd    v1.1.0.8 added port support (default = 25)
-- 2002-07-11  gertd    v1.1.0.7 added ping
-- 2002-05-27  gertd    v1.1.0.6 added ReplyTo, added display name handling, changed HTML mail, added error messages
-- 2002-05-06  gertd    v1.1.0.5 fixed concat receipients bug with reply all
-- 2002/04/11  gertd    v1.1.0.4 added @dumpmsg and more error reporting
-- 2002/03/01  gertd	v1.1.0.3 added HTML mail support @type = 'text/html',
--                               @messagefile and @attachements support
-- 2002/02/20  gertd    v1.0.0.2 fix 7.0 problem install problem
-- 2002/02/13  gertd	v1.0.0.1 first release to web
-- 2000/11/03  gertd    created
-- 
-- @@eof_revsion_marker
-- ***************************************************************************
use master
go

-- installation, copy xpsmtpXX.dll to SQL Server BINN directory
-- SQL Server 7.0
if (charindex(N'7.00', @@version, 0) > 0)
begin
	exec sp_addextendedproc 'xp_smtp_sendmail', 'xpsmtp70.dll'
end

-- SQL Server 2000 needs to use instance aware Registry read 
if (charindex(N'8.00', @@version, 0) > 0)
begin
	exec sp_addextendedproc 'xp_smtp_sendmail', 'xpsmtp80.dll'
end

grant execute on xp_smtp_sendmail to sysadmin

-- ***************************************************************************
-- uninstall, release DLL if in use and unregister
-- dbcc xpsmtp(free)
-- exec sp_dropextendedproc 'xp_smtp_sendmail'
-- go
-- ***************************************************************************

-- ***************************************************************************
-- usage xp_smtp_sendmail
--
-- exec @rc = master.dbo.xp_smtp_sendmail 
-- 
-- NAME			TYPE
-- @FROM    	NVARCHAR(4000), VARCHAR(8000)	= NULL, mandatory
-- @FROM_NAME   NVARCHAR(4000), VARCHAR(8000)	= NULL, optional
-- @TO			NVARCHAR(4000), VARCHAR(8000)	= NULL, mandatory
-- @replyto     NVARCHAR(4000), VARCHAR(8000)	= NULL, optional
-- @CC			NVARCHAR(4000), VARCHAR(8000)	= NULL, optional
-- @BCC			NVARCHAR(4000), VARCHAR(8000)	= NULL, optional
-- @priority    NVARCHAR(10)			        = NORMAL, range [LOW, NORMAL, HIGH], optional
-- @subject		NVARCHAR(4000), VARCHAR(8000)	= NULL, optional
-- @message		NVARCHAR(4000), VARCHAR(8000)	= NULL, optional
-- @messagfile  NVARCHAR(4000), VARCHAR(8000)	= NULL, optional, format = 'c:\file.txt'
-- @type		NVARCHAR(100)			        = 'text/plain', range ['text/plain' | 'text/html'], optional
-- @attachment  NVARCHAR(4000), VARCHAR(8000)	= '', optional, format = 'file1'
-- @attachments NVARCHAR(4000), VARCHAR(8000)	= '', optional, format = 'file1;file2;file3'
-- @server		NVARCHAR(4000), VARCHAR(8000)	= 'smarthost', optional
-- @codepage    INT				                = 0, optional
-- @timeout		INT				                = 10000, optional, range [0 >= WaitForSingleObject]
-- @dumpmsg		NVARCHAR(4000), VARCHAR(8000)	= '', optional, format = 'c:\message.txt' (NOTE: sysadmin role only!)
-- @ping        INT								= [0|1], optional
-- 
-- @rc			INT, range [0 = SUCCESS, 1 = FAILURE]
-- ***************************************************************************

-- ***************************************************************************
-- samples
-- ***************************************************************************

-- ***************************************************************************
-- minimum number of parameters
-- ***************************************************************************
declare @rc int
exec @rc = master.dbo.xp_smtp_sendmail
	@FROM			= N'MyEmail@MyDomain.com',
	@TO				= N'MyFriend@HisDomain.com'
select RC = @rc 
go

-- ***************************************************************************
-- all possible parameters
-- ***************************************************************************
declare @rc int
exec @rc = master.dbo.xp_smtp_sendmail
	@FROM			= N'MyEmail@MyDomain.com',
	@FROM_NAME		= N'Joe Mailman',
	@TO			    = N'MyFriend@HisDomain.com',
    @replyto        = N'Reply to Joe the Mailman',
	@CC			    = N'',
	@BCC			= N'',
	@priority		= N'NORMAL',
	@subject		= N'Hello SQL Server SMTP Mail',
	@message		= N'Goodbye MAPI and Outlook',
	@messagefile	= N'',
	@type			= N'text/plain',
	@attachment		= N'',
	@attachments	= N'',
	@codepage		= 0,
	@server 		= N'mail.mydomain.com'
select RC = @rc 
go

-- ***************************************************************************
-- HTML mail
-- ***************************************************************************
declare @rc int
exec @rc = master.dbo.xp_smtp_sendmail
	@FROM			= N'MyEmail@MyDomain.com',
	@FROM_NAME		= N'Joe Mailman',
	@TO				= N'MyFriend@HisDomain.com',
	@subject		= N'Hello HTML SQL Server SMTP Mail',
	@message		= N'<HTML><H1>this is some content for the body part object</H1></HTML>',
	@type			= N'text/html',
	@server 		= N'mail.mydomain.com'
select RC = @rc 

-- ***************************************************************************
-- using a message file
-- ***************************************************************************
declare @rc int
exec @rc = master.dbo.xp_smtp_sendmail
	@FROM			= N'MyEmail@MyDomain.com',
	@FROM_NAME		= N'Joe Mailman',
	@TO				= N'MyFriend@HisDomain.com',
	@subject		= N'Hello HTML SQL Server SMTP Mail',
	@messagefile	= N'c:\msg.html',
	@type			= N'text/html',
	@server 		= N'mail.mydomain.com'
select RC = @rc 

-- ***************************************************************************
-- using a dump file
-- ***************************************************************************
declare @rc int
exec @rc = master.dbo.xp_smtp_sendmail
	@FROM			= N'MyEmail@MyDomain.com',
	@FROM_NAME		= N'Joe Mailman',
	@TO				= N'MyFriend@HisDomain.com',
	@subject		= N'Hello HTML SQL Server SMTP Mail',
	@message		= N'<HTML><H1>this is some content for the body part object</H1></HTML>',
	@type			= N'text/html',
	@server 		= N'mail.mydomain.com',
    @dumpfile       = N'C:\TEMP\dumpmsg.log'
select RC = @rc 

-- ***************************************************************************
-- using ping
-- ***************************************************************************
declare @rc int
exec @rc = master.dbo.xp_smtp_sendmail
	@server 		= N'mail.mydomain.com',
    @ping			= 1
select RC = @rc 

